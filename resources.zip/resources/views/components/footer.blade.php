<!-- Footer -->
<div class="navbar navbar-sm navbar-footer border-top">
    <div class="container-fluid">
        <span>{{ Carbon\Carbon::now()->year }} -
            Perumda Air Minum Panca Mahottama Kab. Klungkung</span>
    </div>
</div>
<!-- /footer -->
